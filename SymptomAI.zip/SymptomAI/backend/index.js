const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');
const randomstring = require('randomstring');
const sgMail = require('@sendgrid/mail');

const app = express();
const port = 3000;

app.use(cors()); // Enable CORS for all routes

app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'users',
});

db.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  } 
  console.log('Connected to MySQL');
});


app.post('/register', (req, res) => {
  const { firstname, lastname, email, password, username, PhoneNo } = req.body;

  // Check if the email or username already exists in the database
  const checkQuery = 'SELECT * FROM users WHERE Email = ? OR Username = ?';
  const checkValues = [email, username];
  
  db.query(checkQuery, checkValues, (checkErr, checkResult) => {
    if (checkErr) {
      console.error('Error checking user existence in MySQL:', checkErr);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (checkResult.length > 0) {
        // User already exists, return an error
        res.status(400).json({ error: 'User already exists' });
      } else {
        // User doesn't exist, proceed with insertion
        const insertQuery = 'INSERT INTO users (Firstname, Lastname, Email, Password, Username, PhoneNo) VALUES (?, ?, ?, ?, ?, ?)';
        const insertValues = [firstname, lastname, email, password, username, PhoneNo];
        
        db.query(insertQuery, insertValues, (insertErr, insertResult) => {
          if (insertErr) {
            console.error('Error inserting data into MySQL:', insertErr);
            res.status(500).json({ error: 'Internal Server Error' });
          } else {
            console.log('Data inserted into MySQL:', insertResult);
            res.status(200).json({ message: 'Registration successful' });
          }
        });
      }
    }
  });
});


app.post('/login', (req, res) => {
  const { username, password } = req.body;
   
  const selectQuery = 'SELECT * FROM users WHERE Username = ?';
  db.query(selectQuery, [username], (err, results) => {
    if (err) {
      console.error('Error querying MySQL:', err);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
    if (results.length === 0) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }
    const user = results[0];
    // Compare the provided password with the password in the database
    if (password === user.Password) {
      // Passwords match, user is authenticated
      res.status(200).json({ message: 'Login successful' });
    } else {
      res.status(401).json({ error: 'Invalid username or password' });
    }
  });
});
sgMail.setApiKey('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');

app.post('/forget-password', (req, res) => {
  const { Username } = req.body;

  const sql = `SELECT email FROM users WHERE username = ?`;
  db.query(sql, [Username], (error, results) => {
    if (error) {
      console.error('Error searching for user:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const email = results[0].email;
    const newPassword = randomstring.generate(10);

    const updateSql = `UPDATE users SET Password = ? WHERE email = ?`;
    db.query(updateSql, [newPassword, email], (updateError, updateResults) => {
      if (updateError) {
        console.error('Error updating password:', updateError);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (updateResults.affectedRows === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      const msg = {
        to: email,
        from: 'waadmnyawi@gmail.com',
        subject: 'New Password for Symptom AI',
        text: `Your new password for Symptom AI is: ${newPassword}`,
      };

      sgMail
        .send(msg)
        .then(() => {
          console.log('Email sent');
          res.status(200).json({ message: 'New password sent to your email' });
        })
        .catch(emailError => {
          console.error(emailError.toString());
          res.status(500).json({ error: 'Internal Server Error' });
        });
    });
  });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});



